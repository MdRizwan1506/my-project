import color from '../assets/scss/colors.scss'

export const colorCodes = {
    WHITE: color.white,
}