export const contactData = [
    {
        id: '1',
        heading: 'Location:',
        icon: 'fas fa-map-marker-alt',
        text: 'H No 23 Block No A JSL Colony Hisar , Haryaana , 125001'
    }, {
        id: '2',
        heading: 'Open Hours:',
        icon: 'fal fa-clock',
        text: 'Monday-Saturday: 11:00 AM - 23:00 PM'
    }, {
        id: '3',
        heading: 'Email:',
        icon: 'fas fa-envelope',
        text: 'info@example.com'
    }, {
        id: '4',
        heading: 'Call:',
        icon: 'fas fa-phone-alt',
        text: '+91 8383 9449 26'
    }
]