export const aboutCardList = [
    {
        id: '01',
        name: 'Lorem Ipsum',
        description: 'Ulamco laboris nisi ut aliquip ex ea commodo consequat. Et consectetur ducimus vero placeat'
    },
    {
        id: '02',
        name: 'Repellat Nihil',
        description: 'Dolorem est fugiat occaecati voluptate velit esse. Dicta veritatis dolor quod et vel dire leno para dest'
    }, 
    {
        id: '03',
        name: 'Ad ad velit qui',
        description: 'Molestiae officiis omnis illo asperiores. Aut doloribus vitae sunt debitis quo vel nam quis'
    }
]